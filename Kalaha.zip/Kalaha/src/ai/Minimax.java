
package ai;
import kalaha.GameState;


public class Minimax 
{
    public int algo(GameState s, int depth, int ambo, int alpha, int beta, int player)
    {   
        //Initializing variables
        int m_util;
        
        //"maxdepth" is the maximum depth upto which the minimax algorithm works
        int maxdepth=6;
        int bestvalue = -1;
        
        //Creating child node and its copy
        GameState s2 = new GameState();
        s2 = s.clone();
        
       //assigning sample values to alpha and beta 
        alpha = -20000;
        beta = 20000;
        
        //if maximum depth(maxdepth) is reached,we assign utility values to the nodes
        if(depth>=maxdepth) 
        {
            m_util = s2.board[7];
            return m_util;
        }
        
        else //otherwise the child goes on making the moves
        {
            s2.makeMove(ambo);

            if(player == 1)
            {
                for (int a=0;a<6;a++)
                {
                    //find maximum value among the existing ones and assign it to alpha
                    alpha=Math.max(alpha,algo(s2,depth+1,a+1,alpha,beta,1));
                    
                    //alpha-beta pruning starts here and our best move is returned
                    if(bestvalue>alpha)
                      {
                         alpha=bestvalue; 
                      }   
                   if(alpha>=beta)
                      {
                            break;  //prune alpha
                      }    
                }     
            return alpha; 
            }
            
            else
            {
                for(int a=0;a<6;a++)   
                { 
                    //find minimum value among the existing ones and assign it to beta
                    beta=Math.min(beta,algo(s2,depth+1,a+1,alpha,beta,2));
                    
                    //alpha-beta pruning starts here and opponent's worst move is returned
                    if(bestvalue<beta)
                        {
                            beta=bestvalue; 
                        }   
                    if(alpha>=beta)
                        {
                            break; //prune beta
                        }    
                }     
            return beta; 
            }  
        }  
    }  
    
    public int minimaxdepthfirstsearch(GameState currentBoard)
    {
       //Initializing variables
       int finalmove=-1; 
       int depth = 0;
       int player=1;
       int presentvalue;
       int bestvalue = -1;
       
       //Creating parent node and its copy
       GameState s=new GameState();
       GameState s1 = new GameState();
       s1 = currentBoard.clone();
        
       //Initializing alpha and beta 
       int alpha = -20000;
       int beta = 20000;
        
        for(int a=1;a<7;a++)
        {
                if(s1.moveIsPossible(a)) 
                    {
                     presentvalue=algo(s,depth,a,alpha,beta,player); //Determine the best move using the method "algo()" 
                        if(bestvalue<presentvalue) //if the determined value is greater than the current best value,update the best value.
                        {
                            bestvalue=presentvalue;
                            finalmove=a;
                        }
                    }
        }
                return finalmove;   //final move which will be returned to the method "getMove()"
     }
        
}